/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author palom
 */
public class Livro {
    private String titulo;
    private String Autor;
    private String ISBN;
    private int numeroPaginas;
    private double valorCompra;
    
    public Livro(String titulo, String Autor, String ISBN, int numeroPaginas, double valorCompra){
        this.titulo = titulo;
        this.Autor = Autor;
        this.ISBN = ISBN;
        this.numeroPaginas = numeroPaginas;
        this.valorCompra = valorCompra;
    
    }
    
    // get e set

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return Autor;
    }

    public void setAutor(String Autor) {
        this.Autor = Autor;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public int getNumeroPaginas() {
        return numeroPaginas;
    }

    public void setNumeroPaginas(int numeroPaginas) {
        this.numeroPaginas = numeroPaginas;
    }

    public double getValorCompra() {
        return valorCompra;
    }

    public void setValorCompra(double valorCompra) {
        this.valorCompra = valorCompra;
    }
    
    
    
}
