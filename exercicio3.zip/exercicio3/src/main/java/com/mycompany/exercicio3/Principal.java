/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exercicio3;

import model.Livro;
import model.Veiculo;

/**
 *
 * @author palom
 */
public class Principal {

    public static void main(String[] args) {
        
        
        Veiculo v1 = new Veiculo("KWTOPLK", "Azul", 3, 15, 1.5);
        
        v1.setPlaca("OPKKLLW");
        
        System.out.println("Placa: " + v1.getPlaca());
        System.out.println("Cor: " + v1.getCor());
        System.out.println("Numero de passageiros: " + v1.getNumeroPassageiros());
        System.out.println("Velocidade Maxima: " + v1.getVelocidadeMax());
        System.out.println("Consumo médio: " + v1.getConsumoMedio());
        
        // instância da classe 2
        
        Livro L1 = new Livro("Amor a mil", "Paloma", "00003", 500, 250.0);
        
        L1.setTitulo("Amor a mil degraus");
        
        System.out.println("Titulo: " + L1.getTitulo());
        System.out.println("Autor: " + L1.getAutor());
        System.out.println("ISBN: " + L1.getISBN());
        System.out.println("Numero de paginas: " + L1.getNumeroPaginas());
        System.out.println("Valor de Compra: " + L1.getValorCompra());
        
      
        
        
    }
}
