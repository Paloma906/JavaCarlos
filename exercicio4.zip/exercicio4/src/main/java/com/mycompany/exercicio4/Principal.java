/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exercicio4;

import model.Funcionario;


public class Principal {

    public static void main(String[] args) {
        
        Funcionario f1 = new Funcionario("Lopes", 32, "585785758", "Salvador", "Maria", "maria893@gmail.com","5454554");
        
        f1.setLogradouro("Rua do Golfo");
        
        System.out.println("Logradouro: " + f1.getLogradouro());
        System.out.println("Numero: " + f1.getNumero());
        System.out.println("CEP: " + f1.getCEP());
        System.out.println("Cidade: " + f1.getCidade());
        System.out.println("Nome do Funcionario: " + f1.getNome());
        System.out.println("Email" + f1.getEmail());
        System.out.println("Telefone" + f1.getTelefone());
    }
}
