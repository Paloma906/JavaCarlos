/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author palom
 */
public class Funcionario {
    private String Logradouro;
    private int numero;
    private String CEP;
    private String Cidade;
    private String nome;
    private String Email;
    private String telefone;
    
    //construtor
    
    public Funcionario(String Logradouro, int numero, String CEP, String Cidade, String nome, String Email, String telefone){
        this.Logradouro = Logradouro;
        this.numero = numero;
        this.CEP = CEP;
        this.Cidade = Cidade;
        this.nome = nome;
        this.Email = Email;
        this.telefone = telefone;
    }
    
    // get e set

    public String getLogradouro() {
        return Logradouro;
    }

    public void setLogradouro(String Logradouro) {
        this.Logradouro = Logradouro;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getCEP() {
        return CEP;
    }

    public void setCEP(String CEP) {
        this.CEP = CEP;
    }

    public String getCidade() {
        return Cidade;
    }

    public void setCidade(String Cidade) {
        this.Cidade = Cidade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    
    
    
    
}
