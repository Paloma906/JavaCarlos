/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exercicio1;

import model.Livros;

/**
 *
 * @author palom
 */
public class Principal {

    public static void main(String[] args) {
        // instanciando a classe Clientes e criando dois objtos: Livro1 e Livro2
        
        
        Livros Livro1 = new Livros("Mil e Uma Noites", "Folclore",200, 150.0);
        
        System.out.println("Titulo: " + Livro1.getTitulo());
        System.out.println("Autor: " + Livro1.getAutor());
        System.out.println("Numero de paginas: " + Livro1.getNumeroPaginas());
        System.out.println("Preco: " + Livro1.getPreco());
        
        // alterando o titulo do primeiro atributo utilizando set
        Livro1.setTitulo("Montanha Gelada");
        
        
        // instanciando o segundo objeto
        Livros Livro2 = new Livros("O sol é para todos","Harper Lee",400,200.0);
        
        System.out.println("Titulo: " + Livro2.getTitulo());
        System.out.println("Autor: " + Livro2.getAutor());
        System.out.println("Numero de paginas: " + Livro2.getNumeroPaginas());
        System.out.println("Preco: " + Livro2.getPreco());
        
        
    }
}
