/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exercicio2;

import model.Pet;

/**
 *
 * @author palom
 */
public class Principal {

    public static void main(String[] args) {
        
        Pet pet1 = new Pet("Thor",8,"pinscher", "pequeno", "racao");
        
        pet1.setNome("Luffy");
        
        System.out.println("Nome: " + pet1.getNome());
        System.out.println("Idade: " + pet1.getIdade());
        System.out.println("Raca: " + pet1.getRaca());
        System.out.println("Porte: " + pet1.getPorte());
        System.out.println("Alimentacao: " + pet1.getAlimentacao());
        
        Pet pet2 = new Pet("Nina",4,"buldog", "pequeno", "racao");
        
        System.out.println("Nome: " + pet2.getNome());
        System.out.println("Idade: " + pet2.getIdade());
        System.out.println("Raca: " + pet2.getRaca());
        System.out.println("Porte: " + pet2.getPorte());
        System.out.println("Alimentacao: " + pet2.getAlimentacao());
        
        
    }
}